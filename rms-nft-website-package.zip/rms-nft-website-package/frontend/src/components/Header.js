import React from 'react';
import { Link } from 'react-router-dom';
import { useWallet } from '../context/WalletContext';
import { useAuth } from '../context/AuthContext';

const Header = () => {
  const { account, connectWallet, disconnectWallet } = useWallet();
  const { isAuthenticated, logout } = useAuth();

  return (
    <header className="site-header">
      <div className="logo">
        <Link to="/">RMS NFT</Link>
      </div>
      
      <nav className="main-nav">
        <ul>
          <li><Link to="/roadmap">Roadmap</Link></li>
          <li><Link to="/nft-gallery">NFT Gallery</Link></li>
          <li><Link to="/announcements">Announcements</Link></li>
          <li><Link to="/jobs">Job Listings</Link></li>
          {isAuthenticated && <li><Link to="/admin">Admin Panel</Link></li>}
        </ul>
      </nav>
      
      <div className="wallet-section">
        {account ? (
          <div className="wallet-connected">
            <span className="wallet-address">
              {`${account.substring(0, 6)}...${account.substring(account.length - 4)}`}
            </span>
            <button onClick={disconnectWallet} className="btn btn-small">
              Disconnect
            </button>
          </div>
        ) : (
          <button onClick={connectWallet} className="btn btn-primary">
            Connect Wallet
          </button>
        )}
        
        {isAuthenticated && (
          <button onClick={logout} className="btn btn-small btn-logout">
            Logout
          </button>
        )}
      </div>
    </header>
  );
};

export default Header;
