import React from 'react';

const Footer = () => {
  return (
    <footer className="site-footer">
      <div className="footer-content">
        <div className="footer-logo">
          <h3>RMS NFT</h3>
          <p>Building the future of digital collectibles</p>
        </div>
        
        <div className="footer-links">
          <h4>Quick Links</h4>
          <ul>
            <li><a href="/roadmap">Roadmap</a></li>
            <li><a href="/nft-gallery">NFT Gallery</a></li>
            <li><a href="/announcements">Announcements</a></li>
            <li><a href="/jobs">Job Listings</a></li>
          </ul>
        </div>
        
        <div className="footer-social">
          <h4>Connect With Us</h4>
          <div className="social-icons">
            <a href="https://twitter.com/rmsnft" target="_blank" rel="noopener noreferrer">Twitter</a>
            <a href="https://discord.gg/rmsnft" target="_blank" rel="noopener noreferrer">Discord</a>
            <a href="https://opensea.io/collection/rmsnft" target="_blank" rel="noopener noreferrer">OpenSea</a>
          </div>
        </div>
      </div>
      
      <div className="footer-bottom">
        <p>&copy; {new Date().getFullYear()} RMS NFT. All rights reserved.</p>
        <p>
          <a href="/terms">Terms of Service</a> | 
          <a href="/privacy">Privacy Policy</a>
        </p>
      </div>
    </footer>
  );
};

export default Footer;
