import React, { useState, useEffect } from 'react';
import { useWallet } from '../context/WalletContext';

const NdaGate = ({ hasSignedNda, setHasSignedNda, isCallback = false }) => {
  const { account, connectWallet } = useWallet();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');

  // If this is the callback page, check for envelope ID in URL
  useEffect(() => {
    if (isCallback) {
      const params = new URLSearchParams(window.location.search);
      const envelopeId = params.get('envelopeId');
      
      if (envelopeId) {
        // User has completed the signing process, update UI
        setHasSignedNda(true);
      }
    }
  }, [isCallback, setHasSignedNda]);

  // Check NDA status if wallet is connected
  useEffect(() => {
    if (account) {
      checkNdaStatus();
    }
  }, [account]);

  const checkNdaStatus = async () => {
    try {
      setLoading(true);
      // In a real implementation, you would use the connected wallet address
      const response = await fetch(`/api/users/me/nda-status?email=${email}`);
      const data = await response.json();
      
      setHasSignedNda(data.hasSignedNda);
    } catch (error) {
      console.error('Error checking NDA status:', error);
      setError('Failed to check NDA status. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const initiateNdaSigning = async (e) => {
    e.preventDefault();
    
    if (!email || !name) {
      setError('Please provide both email and name to proceed.');
      return;
    }
    
    try {
      setLoading(true);
      setError(null);
      
      // Call backend to initiate DocuSign signing
      const response = await fetch('/api/docusign/initiate-signing', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email,
          name,
          userId: account || email // Use wallet address if available, otherwise email
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Failed to initiate signing');
      }
      
      // Redirect user to DocuSign signing URL
      window.location.href = data.signingUrl;
      
    } catch (error) {
      console.error('Error initiating NDA signing:', error);
      setError(error.message || 'Failed to initiate NDA signing. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (hasSignedNda) {
    return (
      <div className="nda-gate nda-signed">
        <h2>NDA Signed Successfully!</h2>
        <p>Thank you for signing the NDA. You now have access to all protected content.</p>
        <button 
          onClick={() => window.location.href = '/dashboard'}
          className="btn btn-primary"
        >
          Continue to Dashboard
        </button>
      </div>
    );
  }

  return (
    <div className="nda-gate">
      <h2>Welcome to RMS NFT Community</h2>
      <p>To access exclusive content, please sign our Non-Disclosure Agreement.</p>
      
      {!account && (
        <div className="wallet-connect-section">
          <p>Connect your wallet to get started:</p>
          <button onClick={connectWallet} className="btn btn-primary">
            Connect Wallet
          </button>
        </div>
      )}
      
      {account && (
        <div className="nda-form-section">
          <h3>Sign NDA Agreement</h3>
          {error && <div className="error-message">{error}</div>}
          
          <form onSubmit={initiateNdaSigning}>
            <div className="form-group">
              <label htmlFor="name">Full Name:</label>
              <input
                type="text"
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="email">Email Address:</label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            
            <button 
              type="submit" 
              className="btn btn-primary"
              disabled={loading}
            >
              {loading ? 'Processing...' : 'Sign NDA with DocuSign'}
            </button>
          </form>
        </div>
      )}
      
      <div className="public-content-link">
        <p>You can still access our <a href="/roadmap">public roadmap</a> without signing the NDA.</p>
      </div>
    </div>
  );
};

export default NdaGate;
