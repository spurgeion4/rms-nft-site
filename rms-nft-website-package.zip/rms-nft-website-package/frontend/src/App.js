// Create a basic React frontend structure for the RMS NFT website
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import { ethers } from 'ethers';
import './App.css';

// Components
import Header from './components/Header';
import Footer from './components/Footer';
import NdaGate from './components/NdaGate';
import Dashboard from './components/Dashboard';
import Roadmap from './components/Roadmap';
import NFTGallery from './components/NFTGallery';
import Announcements from './components/Announcements';
import JobListings from './components/JobListings';
import AdminPanel from './components/AdminPanel';

// Context
import { WalletProvider } from './context/WalletContext';
import { AuthProvider } from './context/AuthContext';

function App() {
  const [hasSignedNda, setHasSignedNda] = useState(false);
  
  // Check NDA status on load
  useEffect(() => {
    const checkNdaStatus = async () => {
      try {
        // This would be replaced with an actual API call to your backend
        const response = await fetch('/api/users/me/nda-status');
        const data = await response.json();
        setHasSignedNda(data.hasSignedNda);
      } catch (error) {
        console.error('Error checking NDA status:', error);
      }
    };
    
    checkNdaStatus();
  }, []);

  return (
    <AuthProvider>
      <WalletProvider>
        <Router>
          <div className="App">
            <Header />
            <main>
              <Routes>
                <Route path="/" element={<NdaGate hasSignedNda={hasSignedNda} setHasSignedNda={setHasSignedNda} />} />
                <Route 
                  path="/dashboard" 
                  element={hasSignedNda ? <Dashboard /> : <Navigate to="/" />} 
                />
                <Route path="/roadmap" element={<Roadmap />} />
                <Route path="/nft-gallery" element={<NFTGallery />} />
                <Route path="/announcements" element={<Announcements />} />
                <Route path="/jobs" element={<JobListings />} />
                <Route path="/admin" element={<AdminPanel />} />
                <Route path="/nda-callback" element={<NdaGate hasSignedNda={hasSignedNda} setHasSignedNda={setHasSignedNda} isCallback={true} />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </Router>
      </WalletProvider>
    </AuthProvider>
  );
}

export default App;
