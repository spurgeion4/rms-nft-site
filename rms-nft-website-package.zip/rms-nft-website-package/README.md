# RMS NFT Website - Developer Guide

This package contains the source code and instructions for building and deploying the RMS NFT community website with DocuSign NDA integration.

## Project Overview

The RMS NFT website is a community platform with the following key features:

1. **DocuSign NDA Gate**: Users must sign an NDA via DocuSign before accessing protected content
2. **Admin Panel**: React-based dashboard for updating project statuses and uploading media
3. **Community Hub**: Public roadmap, NFT gallery with wallet connection, and announcements
4. **Job Listings**: Display of open positions within the organization

## Folder Structure

```
rms-nft-website-package/
├── backend/             # Node.js/Express backend with DocuSign integration
├── frontend/            # React.js frontend application (starter template)
└── docs/                # Additional documentation
```

## Setup Instructions

### Backend Setup

1. Navigate to the backend directory:
   ```
   cd backend
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Create a `.env` file with the following variables:
   ```
   PORT=8080
   DATABASE_URL=mongodb://localhost:27017/rms_nft_db
   JWT_SECRET=your_jwt_secret_here
   
   # DocuSign API Configuration
   DOCUSIGN_WEBHOOK_SECRET=your_docusign_webhook_secret
   DOCUSIGN_INTEGRATION_KEY=your_docusign_integration_key
   DOCUSIGN_USER_ID=your_docusign_user_id
   DOCUSIGN_ACCOUNT_ID=your_docusign_account_id
   DOCUSIGN_OAUTH_BASE_PATH=account-d.docusign.com
   DOCUSIGN_API_BASE_PATH=https://demo.docusign.net/restapi
   DOCUSIGN_PRIVATE_KEY="-----BEGIN RSA PRIVATE KEY-----\nYour_Private_Key_Content_Here\n-----END RSA PRIVATE KEY-----"
   DOCUSIGN_TEMPLATE_ID=your_docusign_template_id
   APP_RETURN_URL=http://localhost:3000/nda-callback
   ```

4. Start the development server:
   ```
   npm run dev
   ```

### Frontend Setup

The frontend directory contains a starter template. You'll need to:

1. Navigate to the frontend directory:
   ```
   cd frontend
   ```

2. Initialize a new React project:
   ```
   npx create-react-app .
   ```

3. Replace the default `src/App.js` with the provided template in this package.

4. Install required dependencies:
   ```
   npm install react-router-dom ethers axios redux react-redux @reduxjs/toolkit
   ```

5. Create the component files referenced in App.js:
   - `src/components/Header.js`
   - `src/components/Footer.js`
   - `src/components/NdaGate.js`
   - `src/components/Dashboard.js`
   - `src/components/Roadmap.js`
   - `src/components/NFTGallery.js`
   - `src/components/Announcements.js`
   - `src/components/JobListings.js`
   - `src/components/AdminPanel.js`
   - `src/context/WalletContext.js`
   - `src/context/AuthContext.js`

6. Start the development server:
   ```
   npm start
   ```

## Deploying to Netlify

### Frontend Deployment

1. **Prepare your frontend for production**:
   ```
   cd frontend
   npm run build
   ```

2. **Deploy to Netlify**:
   - Sign up/login to [Netlify](https://www.netlify.com/)
   - From the Netlify dashboard, click "New site from Git"
   - Connect to your Git repository
   - Set build command to `npm run build`
   - Set publish directory to `build`
   - Configure environment variables in the Netlify dashboard (for frontend API URLs)
   - Click "Deploy site"

3. **Configure redirects for SPA routing**:
   Create a `_redirects` file in the `public` directory with:
   ```
   /*    /index.html   200
   ```

### Backend Deployment

The backend cannot be directly deployed to Netlify's standard hosting. You have several options:

1. **Netlify Functions** (Recommended for this project):
   - Convert your Express routes to serverless functions
   - Create a `netlify.toml` file in your project root:
     ```toml
     [build]
       functions = "functions"
     
     [[redirects]]
       from = "/api/*"
       to = "/.netlify/functions/:splat"
       status = 200
     ```
   - Create a `functions` directory and convert your Express routes to serverless functions
   - Example function structure available in the `docs` directory

2. **Separate Backend Hosting**:
   - Deploy your Node.js backend to a service like:
     - Heroku
     - DigitalOcean App Platform
     - AWS Elastic Beanstalk
     - Google Cloud Run
   - Update your frontend API URLs to point to this hosted backend

3. **MongoDB Atlas**:
   - Create a MongoDB Atlas account
   - Set up a new cluster
   - Replace the `DATABASE_URL` in your environment variables with the MongoDB Atlas connection string

## DocuSign Integration

To complete the DocuSign integration:

1. Create a DocuSign developer account at [developers.docusign.com](https://developers.docusign.com/)
2. Create an integration key (client ID) in the DocuSign eSignature API section
3. Generate an RSA keypair and associate it with your integration key
4. Create an NDA template in your DocuSign account and note its Template ID
5. Configure Connect (webhooks) in DocuSign to send envelope status updates to your backend
6. Update all DocuSign-related environment variables in your backend

## Additional Resources

- [DocuSign Developer Documentation](https://developers.docusign.com/docs/esign-rest-api/how-to/request-signature-email-remote/)
- [Netlify Functions Documentation](https://docs.netlify.com/functions/overview/)
- [React Router Documentation](https://reactrouter.com/en/main)
- [Ethers.js Documentation](https://docs.ethers.org/v5/)

## Contact

For questions or support, please contact the project maintainer.
