const express = require("express");
const router = express.Router();
const docusign = require("docusign-esign");
const User = require("../models/User");

// DocuSign API Configuration - these should be in .env
const DOCUSIGN_INTEGRATION_KEY = process.env.DOCUSIGN_INTEGRATION_KEY;
const DOCUSIGN_USER_ID = process.env.DOCUSIGN_USER_ID;
const DOCUSIGN_ACCOUNT_ID = process.env.DOCUSIGN_ACCOUNT_ID;
const DOCUSIGN_OAUTH_BASE_PATH = process.env.DOCUSIGN_OAUTH_BASE_PATH;
const DOCUSIGN_API_BASE_PATH = process.env.DOCUSIGN_API_BASE_PATH;
let DOCUSIGN_PRIVATE_KEY = process.env.DOCUSIGN_PRIVATE_KEY;
const DOCUSIGN_TEMPLATE_ID = process.env.DOCUSIGN_TEMPLATE_ID;
const DOCUSIGN_CLIENT_USER_ID_PREFIX = "ndaclient_";
const APP_RETURN_URL = process.env.APP_RETURN_URL || "http://localhost:3000/nda-signed";

// Check for private key and format it; log warning if missing
if (DOCUSIGN_PRIVATE_KEY) {
    DOCUSIGN_PRIVATE_KEY = DOCUSIGN_PRIVATE_KEY.replace(/\\n/g, "\n");
} else {
    console.warn("CRITICAL: DOCUSIGN_PRIVATE_KEY is not set in .env file. DocuSign signing initiation will fail.");
}

async function getAuthenticatedApiClient() {
    if (!DOCUSIGN_INTEGRATION_KEY || !DOCUSIGN_USER_ID || !DOCUSIGN_PRIVATE_KEY || !DOCUSIGN_OAUTH_BASE_PATH || !DOCUSIGN_API_BASE_PATH) {
        console.error("DocuSign JWT Grant: Missing one or more required environment variables (INTEGRATION_KEY, USER_ID, PRIVATE_KEY, OAUTH_BASE_PATH, API_BASE_PATH).");
        throw new Error("DocuSign authentication configuration is incomplete.");
    }

    const apiClient = new docusign.ApiClient();
    apiClient.setOAuthBasePath(DOCUSIGN_OAUTH_BASE_PATH);

    try {
        const results = await apiClient.requestJWTUserToken(
            DOCUSIGN_INTEGRATION_KEY,
            DOCUSIGN_USER_ID,
            ["signature", "impersonation"],
            Buffer.from(DOCUSIGN_PRIVATE_KEY),
            3600
        );
        apiClient.addDefaultHeader("Authorization", "Bearer " + results.body.access_token);
        apiClient.setBasePath(DOCUSIGN_API_BASE_PATH);
        return apiClient;
    } catch (error) {
        console.error("Error authenticating with DocuSign JWT Grant:", error);
        if (error.response) {
            console.error("DocuSign Error Response:", error.response.body);
        }
        throw new Error("DocuSign authentication failed.");
    }
}

router.post("/initiate-signing", async (req, res) => {
    const { email, name, userId } = req.body;

    if (!email || !name || !userId) {
        return res.status(400).json({ message: "Email, name, and userId are required." });
    }
    if (!DOCUSIGN_TEMPLATE_ID) {
        console.error("DocuSign Template ID is not configured.");
        return res.status(500).json({ message: "DocuSign template not configured on server." });
    }
    if (!DOCUSIGN_PRIVATE_KEY) { // Check again specifically for this route
        console.error("DocuSign initiate-signing: DOCUSIGN_PRIVATE_KEY is not set. Cannot proceed.");
        return res.status(500).json({ message: "DocuSign signing cannot be initiated due to missing server configuration (private key)." });
    }

    try {
        const apiClient = await getAuthenticatedApiClient();
        const envelopesApi = new docusign.EnvelopesApi(apiClient);

        const envelopeDefinition = new docusign.EnvelopeDefinition();
        envelopeDefinition.templateId = DOCUSIGN_TEMPLATE_ID;
        envelopeDefinition.status = "sent";

        const signer = new docusign.TemplateRole();
        signer.email = email;
        signer.name = name;
        signer.roleName = "Signer";
        signer.clientUserId = DOCUSIGN_CLIENT_USER_ID_PREFIX + userId;

        envelopeDefinition.templateRoles = [signer];

        const results = await envelopesApi.createEnvelope(DOCUSIGN_ACCOUNT_ID, { envelopeDefinition });
        const envelopeId = results.envelopeId;
        console.log(`DocuSign envelope created successfully. Envelope ID: ${envelopeId}`);

        const viewRequest = new docusign.RecipientViewRequest();
        viewRequest.returnUrl = `${APP_RETURN_URL}?envelopeId=${envelopeId}`;
        viewRequest.authenticationMethod = "none";
        viewRequest.email = email;
        viewRequest.userName = name;
        viewRequest.clientUserId = signer.clientUserId;

        const recipientView = await envelopesApi.createRecipientView(DOCUSIGN_ACCOUNT_ID, envelopeId, { recipientViewRequest: viewRequest });
        
        console.log(`DocuSign signing URL generated for ${email}`);
        res.json({ signingUrl: recipientView.url, envelopeId: envelopeId });

    } catch (error) {
        console.error("Error in /initiate-signing:", error);
        if (error.response && error.response.body) {
            console.error("DocuSign API Error details:", JSON.stringify(error.response.body, null, 2));
            return res.status(500).json({ message: "Failed to initiate DocuSign signing. API error.", details: error.response.body });
        }
        res.status(500).json({ message: "Failed to initiate DocuSign signing.", details: error.message });
    }
});

module.exports = router;
console.log("DocuSign actions route (docusignActions.js) updated for resilience to missing private key.");

