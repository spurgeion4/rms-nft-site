// DocuSign Webhook Handler (docusignEvents.js)
const express = require("express");
const router = express.Router();
const crypto = require("crypto"); // For webhook signature verification
const User = require("../models/User"); // Import the User model

// Ensure DOCUSIGN_WEBHOOK_SECRET is loaded from environment variables
const DOCUSIGN_WEBHOOK_SECRET = process.env.DOCUSIGN_WEBHOOK_SECRET;

/**
 * Updates the user's NDA status in the database.
 */
async function updateUserNdaStatus(signerEmail, signerName, envelopeId, ndaStatus) {
    console.log(`Database: Attempting to update NDA status for ${signerEmail} to ${ndaStatus} for envelope ${envelopeId}`);
    try {
        // Find user by email. If user doesn't exist, we might create them or log an error based on requirements.
        // For now, we assume the user should exist or we create a basic profile.
        let user = await User.findOne({ email: signerEmail });

        if (!user) {
            // Optionally, create a new user if they don't exist.
            // This depends on the application flow - should users pre-register or are they created on first NDA sign?
            // For this example, let's create a new user if not found.
            console.log(`Database: User with email ${signerEmail} not found. Creating new user.`);
            user = new User({
                email: signerEmail,
                name: signerName, // Capture name from DocuSign if available
                hasSignedNda: ndaStatus,
                docusignEnvelopeId: envelopeId,
                lastNdaUpdate: new Date()
            });
            await user.save();
            console.log(`Database: Successfully created new user ${signerEmail} and updated NDA status.`);
            return { success: true, user, created: true };
        } else {
            // User exists, update their NDA status
            user.hasSignedNda = ndaStatus;
            user.docusignEnvelopeId = envelopeId;
            user.lastNdaUpdate = new Date();
            if (signerName && !user.name) { // Update name if it wasn't set previously
                user.name = signerName;
            }
            await user.save();
            console.log(`Database: Successfully updated NDA status for ${signerEmail}`);
            return { success: true, user, created: false };
        }
    } catch (error) {
        console.error(`Database: Error updating NDA status for ${signerEmail}:`, error);
        return { success: false, message: "Database error: " + error.message };
    }
}


/**
 * Helper function for signature verification.
 */
function verifySignature(payload, signature, secret) {
    if (!payload || !signature || !secret) {
        console.warn("DocuSign Webhook: Missing payload, signature, or secret for verification.");
        return false;
    }
    try {
        const hmac = crypto.createHmac("sha256", secret);
        hmac.update(payload);
        const computedSignature = hmac.digest("base64");
        return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(computedSignature));
    } catch (error) {
        console.error("DocuSign Webhook: Error during signature verification:", error);
        return false;
    }
}

/**
 * @route POST /api/docusign/events
 * @desc Handles webhook events from DocuSign.
 * @access Public (secured with signature verification)
 */
router.post("/events", async (req, res) => {
    if (!DOCUSIGN_WEBHOOK_SECRET) {
        console.error("DocuSign Webhook: DOCUSIGN_WEBHOOK_SECRET is not configured. Cannot verify signature.");
        return res.status(500).send("Webhook secret not configured.");
    }

    const signature = req.headers["x-docusign-signature-1"];
    if (!req.rawBody) {
        console.error("DocuSign Webhook: Raw request body not available for signature verification.");
        return res.status(500).send("Internal server error: Raw body not available.");
    }

    if (!verifySignature(req.rawBody, signature, DOCUSIGN_WEBHOOK_SECRET)) {
        console.warn("DocuSign Webhook: Invalid signature.");
        return res.status(401).send("Invalid signature.");
    }
    console.log("DocuSign Webhook: Signature verified successfully.");

    const eventData = req.body;
    // console.log("Received DocuSign event:", JSON.stringify(eventData, null, 2)); // Log full payload if needed for debugging

    // Process the event
    if (eventData.event === "envelope-completed" && eventData.data && eventData.data.envelopeSummary) {
        const envelopeSummary = eventData.data.envelopeSummary;
        const envelopeId = envelopeSummary.envelopeId;
        
        if (envelopeSummary.recipients && envelopeSummary.recipients.signers) {
            for (const signer of envelopeSummary.recipients.signers) {
                if (signer.status === "completed") {
                    const signerEmail = signer.email;
                    const signerName = signer.name;
                    console.log(`NDA signed by ${signerName} (${signerEmail}), Envelope ID: ${envelopeId}.`);
                    
                    // Update user's NDA status in the database
                    const dbUpdateResult = await updateUserNdaStatus(signerEmail, signerName, envelopeId, true);
                    if (dbUpdateResult.success) {
                        console.log(`Successfully processed NDA completion for ${signerEmail}. User created: ${dbUpdateResult.created}`);
                    } else {
                        console.warn(`Failed to update database for ${signerEmail}: ${dbUpdateResult.message}`);
                        // Potentially send a different response or log for manual intervention
                        // For now, we still send a 200 to DocuSign to acknowledge receipt and prevent retries for this specific issue.
                    }
                } else {
                    // Handle other signer statuses if necessary (e.g., declined)
                    console.log(`Signer ${signer.email} status: ${signer.status} for envelope ${envelopeId}.`);
                    // Optionally, update declined status in DB if needed: await updateUserNdaStatus(signer.email, signer.name, envelopeId, false, signer.status);
                }
            }
        }
    } else {
        console.log(`Received DocuSign event: ${eventData.event}. No specific action taken for this event type.`);
    }

    res.status(200).send("Event received and processed.");
});

module.exports = router;

console.log("DocuSign webhook handler (docusignEvents.js) updated with Mongoose User model integration.");

