const express = require("express");
const router = express.Router();
const User = require("../models/User");

// TODO: Add authentication middleware to protect this route and get authenticated user

/**
 * @route GET /api/users/me/nda-status
 * @desc Get the NDA status for the currently authenticated user (or by email for now)
 * @access Private (should be authenticated)
 */
router.get("/me/nda-status", async (req, res) => {
    // For now, let's assume email is passed as a query parameter for testing.
    // In a real app, you would get the user ID/email from the authenticated session (e.g., req.user.id)
    const { email } = req.query;

    if (!email) {
        return res.status(400).json({ message: "Email query parameter is required for now." });
    }

    try {
        const user = await User.findOne({ email: email.toLowerCase() });

        if (!user) {
            // If user not found, it implies they haven't signed the NDA or even started the process.
            return res.json({ 
                hasSignedNda: false, 
                message: "User not found or NDA not signed.",
                email: email
            });
        }

        res.json({
            email: user.email,
            hasSignedNda: user.hasSignedNda,
            docusignEnvelopeId: user.docusignEnvelopeId,
            lastNdaUpdate: user.lastNdaUpdate,
            name: user.name
        });

    } catch (error) {
        console.error("Error fetching NDA status:", error);
        res.status(500).json({ message: "Server error while fetching NDA status." });
    }
});

module.exports = router;
console.log("User routes (userRoutes.js) for NDA status created.");

